#!/bin/bash

/usr/bin/helm unittest --helm3 --color ./mesh;
